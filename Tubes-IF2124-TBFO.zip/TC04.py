def do_something(x):
    # ini comment
    x + 5 = 11
    5 + 5 = 10
    tes_prog = tes
    if x == 0:
        return 0
    elif x + 4 == 1:
        if True:
            return 3
        else:
            return 2
    elif x == 32:
        return 4
    else:
        return "tes"
