N = 5
i = 1
sum = 0

while (i <= 5) :
    sum += i
    i += 1