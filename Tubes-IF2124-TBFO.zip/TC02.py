if(true):
   aas+=1
elif(true == true):
   print(true)
if(a > 4):
   a = 3
elif(a < 4 and a > 1):
   a-=9
else:
   a-=1
